package com.in28minutes.springboot.basics.springbootmailexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootMailExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootMailExampleApplication.class, args);
	}

}
